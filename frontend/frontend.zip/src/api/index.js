// src/api/index.js

export * as authAPI from "./authAPI";
export * as goalAPI from "./goalAPI";
export * as statementAPI from "./statementAPI";
